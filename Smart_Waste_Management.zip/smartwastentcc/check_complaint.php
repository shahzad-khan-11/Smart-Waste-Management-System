<?php
header('Content-Type: application/json');

$username = "smartwaste_ntcc";
$password = "waste123";
$connection_string = "localhost/orcl";

$conn = oci_connect($username, $password, $connection_string);
if (!$conn) {
    echo json_encode(["error" => "❌ Database connection failed"]);
    exit;
}

$pickup_id = trim($_GET['pickup_id'] ?? '');
if (empty($pickup_id)) {
    echo json_encode(["error" => "❌ Pickup ID required"]);
    exit;
}

$sql = "SELECT TO_CHAR(created_at, 'YYYY-MM-DD HH24:MI:SS') AS CREATED_AT
        FROM complaints
        WHERE pickup_id = :pid
        ORDER BY created_at DESC FETCH FIRST 1 ROWS ONLY";

$stid = oci_parse($conn, $sql);
oci_bind_by_name($stid, ":pid", $pickup_id);
oci_execute($stid);
$row = oci_fetch_array($stid, OCI_ASSOC);

if ($row && !empty($row['CREATED_AT'])) {
    $last_date_str = $row['CREATED_AT'];

    $last_date = DateTime::createFromFormat('Y-m-d H:i:s', $last_date_str);
    $today = new DateTime();

    if ($last_date) {
        $diff = $today->diff($last_date)->days;

        if ($diff < 3) {
            echo json_encode(["already_complained" => true]);
            oci_free_statement($stid);
            oci_close($conn);
            exit;
        }
    }
}

echo json_encode(["already_complained" => false]);

oci_free_statement($stid);
oci_close($conn);
?>
