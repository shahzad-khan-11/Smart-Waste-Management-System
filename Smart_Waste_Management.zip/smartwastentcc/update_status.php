<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin | Update Status</title>
<style>
body {
  font-family: 'Poppins', sans-serif;
  background: linear-gradient(135deg, #1c4b33, #2e8b57);
  color: #333;
  margin: 0;
  padding: 0;
}
.container {
  background: #fff;
  max-width: 600px;
  margin: 70px auto;
  padding: 40px;
  border-radius: 15px;
  box-shadow: 0 6px 20px rgba(0,0,0,0.3);
  text-align: center;
  animation: fadeIn 0.8s ease-in-out;
}
@keyframes fadeIn {
  from {opacity: 0; transform: translateY(-20px);}
  to {opacity: 1; transform: translateY(0);}
}
h2 {
  color: #136b3b;
}
label {
  font-weight: bold;
  display: block;
  margin-top: 15px;
}
input, select {
  width: 90%;
  padding: 10px;
  margin-top: 5px;
  border-radius: 8px;
  border: 1px solid #ccc;
  font-size: 15px;
}
button {
  margin-top: 25px;
  background: #2e8b57;
  color: white;
  padding: 12px 25px;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 16px;
  transition: 0.3s;
}
button:hover {
  background: #1f6b40;
}
.msg-box {
  margin-top: 30px;
  padding: 15px;
  border-radius: 10px;
  font-weight: bold;
}
.success {
  background: #d4edda;
  color: #155724;
}
.error {
  background: #f8d7da;
  color: #721c24;
}
.warning {
  background: #fff3cd;
  color: #856404;
}
</style>
</head>
<body>

<div class="container">
  <h2>🔧 Admin - Update Status</h2>

  <form method="POST" action="">
    <label>Update Type:</label>
    <select name="type" required>
      <option value="">-- Select Type --</option>
      <option value="complaint">Complaint</option>
      <option value="pickup">Pickup</option>
    </select>

    <label>ID:</label>
    <input type="text" name="id" placeholder="Enter Complaint ID or Pickup ID" required>

    <label>New Status:</label>
    <select name="status" required>
      <option value="Pending">Pending</option>
      <option value="In Progress">In Progress</option>
      <option value="Completed">Completed</option>
    </select>

    <button type="submit">✅ Update</button>
  </form>

<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'] ?? '';
    $id = trim($_POST['id'] ?? '');
    $new_status = trim($_POST['status'] ?? '');

    if ($type === '' || $id === '' || $new_status === '') {
        echo "<div class='msg-box warning'>⚠️ All fields are required!</div>";
    } else {
        $conn = oci_connect("smartwaste_ntcc", "waste123", "localhost/orcl");
        if (!$conn) {
            die("<div class='msg-box error'>❌ Database connection failed!</div>");
        }


        $email = '';
        $subject = '';
        $body = '';

        if ($type === 'complaint') {
            $sql = "SELECT email FROM complaints WHERE complaint_id = :cid";
            $stid = oci_parse($conn, $sql);
            oci_bind_by_name($stid, ":cid", $id);
            oci_execute($stid);
            $row = oci_fetch_array($stid, OCI_ASSOC);
            oci_free_statement($stid);

            if ($row) {
                $email = $row['EMAIL'];
                $updateSql = "UPDATE complaints SET status = :sts WHERE complaint_id = :cid";
                $stid2 = oci_parse($conn, $updateSql);
                oci_bind_by_name($stid2, ":sts", $new_status);
                oci_bind_by_name($stid2, ":cid", $id);
                oci_execute($stid2);
                oci_commit($conn);
                oci_free_statement($stid2);

                $subject = "Complaint Status Updated (ID #$id)";
                $body = "
                    <h3>Dear User,</h3>
                    <p>Your complaint <b>ID #$id</b> is now marked as <b>$new_status</b>.</p>
                    <p>Thank you for using Smart Waste Management 💚</p>";

                $successMsg = "✅ Complaint status updated successfully!";
            } else {
                echo "<div class='msg-box error'>❌ Complaint ID not found.</div>";
                exit;
            }
        }

        if ($type === 'pickup') {
            $sql = "SELECT email, name FROM pickup_requests WHERE pickup_id = :pid";
            $stid = oci_parse($conn, $sql);
            oci_bind_by_name($stid, ":pid", $id);
            oci_execute($stid);
            $row = oci_fetch_array($stid, OCI_ASSOC);
            oci_free_statement($stid);

            if ($row) {
                $email = $row['EMAIL'];
                $name = $row['NAME'];
                $updateSql = "UPDATE pickup_requests SET status = :sts WHERE pickup_id = :pid";
                $stid2 = oci_parse($conn, $updateSql);
                oci_bind_by_name($stid2, ":sts", $new_status);
                oci_bind_by_name($stid2, ":pid", $id);
                oci_execute($stid2);
                oci_commit($conn);
                oci_free_statement($stid2);

                $subject = "Pickup Request Status Updated (ID #$id)";
                $body = "
                    <h3>Dear $name,</h3>
                    <p>Your pickup request <b>ID #$id</b> is now marked as <b>$new_status</b>.</p>
                    <p>Thank you for helping us keep the city clean 💚</p>";

                $successMsg = "✅ Pickup request status updated successfully!";
            } else {
                echo "<div class='msg-box error'>❌ Pickup ID not found.</div>";
                exit;
            }
        }

      
        if (!empty($email)) {
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'khanshahzad90020@gmail.com'; 
                $mail->Password = 'prgfgnfwsdybbede'; 
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                $mail->setFrom('khanshahzad90020@gmail.com', 'Smart Waste System');
                $mail->addAddress($email);
                $mail->isHTML(true);
                $mail->Subject = $subject;
                $mail->Body = $body;
                $mail->send();

                echo "<div class='msg-box success'>$successMsg Email sent successfully! 📧</div>";
            } catch (Exception $e) {
                echo "<div class='msg-box warning'>⚠️ Status updated, but email failed: {$mail->ErrorInfo}</div>";
            }
        } else {
            echo "<div class='msg-box success'>$successMsg (No email found for this record.)</div>";
        }

        oci_close($conn);
    }
}
?>
</div>
</body>
</html>
