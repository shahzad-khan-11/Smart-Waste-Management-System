<?php

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

$username = "smartwaste_ntcc";
$password = "waste123";
$connection_string = "localhost/orcl";

$conn = oci_connect($username, $password, $connection_string);
if (!$conn) {
    $e = oci_error();
    die("<p style='color:red;text-align:center;'>❌ Connection Failed: " . $e['message'] . "</p>");
}

$search_type = $_POST['search_type'] ?? '';
$search_value = trim($_POST['search_value'] ?? '');

if (empty($search_type) || empty($search_value)) {
    die("<p style='color:red;text-align:center;'>❌ Please select a search type and enter a value.</p>");
}

if ($search_type === 'mobile') {
    $sql = "SELECT * FROM pickup_requests WHERE mobile = :val ORDER BY pickup_date DESC";
} elseif ($search_type === 'pickup') {
    $sql = "SELECT * FROM pickup_requests WHERE pickup_id = :val";
} elseif ($search_type === 'complaint') {
   
    $sql = "SELECT c.complaint_id, c.mobile, c.forward_to, c.message, c.created_at,
                   c.status, p.pickup_id
            FROM complaints c
            LEFT JOIN pickup_requests p ON c.pickup_id = p.pickup_id
            WHERE c.complaint_id = :val OR c.mobile = :val
            ORDER BY c.created_at DESC";
} else {
    die("<p style='color:red;text-align:center;'>❌ Invalid search type.</p>");
}

$stid = oci_parse($conn, $sql);
oci_bind_by_name($stid, ":val", $search_value);
oci_execute($stid);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>History Result</title>
<style>
body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #2e8b57, #1c4b33);
    color: #333;
    margin: 0;
    padding: 0;
}
.container {
    max-width: 1000px;
    margin: 60px auto;
    background: #fff;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 6px 20px rgba(0,0,0,0.2);
    animation: fadeIn 0.8s ease-in-out;
}
@keyframes fadeIn {
  from {opacity:0; transform: translateY(10px);}
  to {opacity:1; transform: translateY(0);}
}
h1 {
    text-align: center;
    color: #136b3b;
}
.table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 25px;
}
.table th, .table td {
    padding: 12px;
    border-bottom: 1px solid #ddd;
    text-align: center;
}
.table th {
    background: #2e8b57;
    color: #fff;
}
.table tr:hover {
    background: #f9f9f9;
}
.status {
    padding: 6px 12px;
    border-radius: 20px;
    color: #fff;
    font-weight: bold;
}
.Pending { background: #f0ad4e; }
.InProgress { background: #5bc0de; }
.Completed { background: #5cb85c; }
.btn {
    display: inline-block;
    margin: 20px 10px;
    background: #2e8b57;
    color: #fff;
    padding: 10px 20px;
    border-radius: 8px;
    text-decoration: none;
    transition: 0.3s;
}
.btn:hover {
    background: #236b45;
}
.photo {
    width: 80px;
    height: 60px;
    border-radius: 8px;
    object-fit: cover;
}
.refresh {
    float: right;
    margin-top: -40px;
    background: #5bc0de;
}
</style>
</head>
<body>
<div class="container">
<h1>📑 Search Results</h1>
<a class="btn refresh" href="#" onclick="window.location.reload();">🔄 Refresh</a>

<?php
$rows = false;
while ($row = oci_fetch_array($stid, OCI_ASSOC + OCI_RETURN_LOBS)) {
    if (!$rows) {
        if ($search_type === 'complaint') {
            echo "<table class='table'>
                    <tr>
                        <th>Complaint ID</th>
                        <th>Mobile</th>
                        <th>Forward To</th>
                        <th>Message</th>
                        <th>Date</th>
                        <th>Pickup ID</th>
                        <th>Status</th>
                    </tr>";
        } else {
            echo "<table class='table'>
                    <tr>
                        <th>Pickup ID</th>
                        <th>Name</th>
                        <th>Mobile</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Photo</th>
                        <th>Description</th>
                    </tr>";
        }
        $rows = true;
    }

    if ($search_type === 'complaint') {
        $status_raw = trim($row['STATUS'] ?? 'Pending');
        $status_clean = strtolower(str_replace(' ', '', $status_raw));
        if ($status_clean == 'inprogress') $status_class = 'InProgress';
        elseif ($status_clean == 'completed') $status_class = 'Completed';
        else $status_class = 'Pending';

        echo "<tr>
                <td>{$row['COMPLAINT_ID']}</td>
                <td>{$row['MOBILE']}</td>
                <td>{$row['FORWARD_TO']}</td>
                <td>" . nl2br(htmlspecialchars($row['MESSAGE'])) . "</td>
                <td>{$row['CREATED_AT']}</td>
                <td>{$row['PICKUP_ID']}</td>
                <td><span class='status {$status_class}'>" . htmlspecialchars($status_raw) . "</span></td>
              </tr>";
    } else {
        $photo = !empty($row['PHOTO']) ? $row['PHOTO'] : 'assets/css/truck.jpg';
        $desc = isset($row['DESCRIPTION']) && is_object($row['DESCRIPTION']) ? $row['DESCRIPTION']->load() : $row['DESCRIPTION'];
        $status_raw = trim($row['STATUS'] ?? 'Pending');
        $status_clean = strtolower(str_replace(' ', '', $status_raw));
        if ($status_clean == 'inprogress') $status_class = 'InProgress';
        elseif ($status_clean == 'completed') $status_class = 'Completed';
        else $status_class = 'Pending';

        echo "<tr>
                <td>{$row['PICKUP_ID']}</td>
                <td>{$row['NAME']}</td>
                <td>{$row['MOBILE']}</td>
                <td>{$row['PICKUP_DATE']}</td>
                <td>{$row['PICKUP_TIME']}</td>
                <td><span class='status {$status_class}'>" . htmlspecialchars($status_raw) . "</span></td>
                <td><img src='{$photo}' class='photo'></td>
                <td>" . nl2br(htmlspecialchars($desc)) . "</td>
              </tr>";
    }
}

if ($rows) {
    echo "</table>";
} else {
    echo "<p style='text-align:center;color:#d9534f;'>❌ No records found for your search.</p>";
}

oci_free_statement($stid);
oci_close($conn);
?>
<div style="text-align:center;">
<a class="btn" href="index.html">🏠 Home</a>
<a class="btn" href="history.html">🔁 New Search</a>
</div>
</div>
</body>
</html>
