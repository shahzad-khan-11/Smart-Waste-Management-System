<?php
header('Content-Type: application/json');

$username = "smartwaste_ntcc";
$password = "waste123";
$connection_string = "localhost/orcl";

$conn = oci_connect($username, $password, $connection_string);
if (!$conn) {
    echo json_encode(["error" => "❌ Database connection failed"]);
    exit;
}

$pickup_id = trim($_GET['pickup_id'] ?? '');
if (empty($pickup_id)) {
    echo json_encode(["error" => "❌ Pickup ID is required"]);
    exit;
}

$sql = "SELECT pickup_id, name, address, status, TO_CHAR(pickup_date, 'YYYY-MM-DD') AS pickup_date
        FROM pickup_requests 
        WHERE pickup_id = :pickup_id";

$stid = oci_parse($conn, $sql);
oci_bind_by_name($stid, ":pickup_id", $pickup_id);
oci_execute($stid);
$row = oci_fetch_array($stid, OCI_ASSOC + OCI_RETURN_LOBS);

if (!$row) {
    echo json_encode(["error" => "❌ No record found for this Pickup ID"]);
    exit;
}

$address = ($row['ADDRESS'] instanceof OCILob) ? $row['ADDRESS']->load() : $row['ADDRESS'];

$pickup_date_str = $row['PICKUP_DATE'];
$pickup_dt = DateTime::createFromFormat('Y-m-d', $pickup_date_str);
$today = new DateTime();

$days_diff = $today->diff($pickup_dt)->days;
$can_complain = ($today > $pickup_dt && $days_diff >= 3);

echo json_encode([
    "pickup_number" => $row['PICKUP_ID'],  
    "name" => $row['NAME'],
    "pickup_date" => $pickup_date_str,
    "address" => $address,
    "status" => $row['STATUS'],
    "can_complain" => $can_complain
]);

oci_free_statement($stid);
oci_close($conn);
?>
