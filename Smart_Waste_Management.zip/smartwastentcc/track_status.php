<?php
// 🔒 Prevent cache
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

$username = "smartwaste_ntcc";
$password = "waste123";
$connection_string = "localhost/orcl";

$conn = oci_connect($username, $password, $connection_string);
if (!$conn) {
    $e = oci_error();
    die("❌ Connection Failed: " . $e['message']);
}

$pickup_id   = trim($_POST['pickup_id'] ?? '');
$mobile      = trim($_POST['mobile'] ?? '');
$complaint_id = trim($_POST['complaint_id'] ?? '');

if (empty($pickup_id) && empty($mobile) && empty($complaint_id)) {
    die("<p style='color:red; text-align:center;'>❌ Please enter Pickup ID, Mobile Number, or Complaint ID.</p>");
}

if (!empty($pickup_id)) {
    $sql = "SELECT * FROM pickup_requests WHERE pickup_id = :pickup_id";
    $stid = oci_parse($conn, $sql);
    oci_bind_by_name($stid, ":pickup_id", $pickup_id);
} elseif (!empty($mobile)) {
    $sql = "SELECT * FROM pickup_requests WHERE mobile = :mobile ORDER BY pickup_date DESC FETCH FIRST 1 ROWS ONLY";
    $stid = oci_parse($conn, $sql);
    oci_bind_by_name($stid, ":mobile", $mobile);
} else {
    $sql = "SELECT * FROM complaints WHERE complaint_id = :complaint_id";
    $stid = oci_parse($conn, $sql);
    oci_bind_by_name($stid, ":complaint_id", $complaint_id);
}

oci_execute($stid);
$row = oci_fetch_array($stid, OCI_ASSOC + OCI_RETURN_LOBS);

oci_free_statement($stid);
oci_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Track Status</title>
<style>
body {
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(135deg, #2e8b57, #1c4b33);
    color: #333;
    margin: 0;
    padding: 0;
}
.container {
    background: #fff;
    max-width: 700px;
    margin: 80px auto;
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 6px 20px rgba(0,0,0,0.2);
    animation: fadeIn 1s ease-in-out;
}
@keyframes fadeIn {
    from {opacity: 0; transform: translateY(-20px);}
    to {opacity: 1; transform: translateY(0);}
}
h1 {
    color: #136b3b;
    display: flex;
    align-items: center;
    gap: 10px;
}
.status {
    display: inline-block;
    padding: 8px 18px;
    border-radius: 20px;
    color: #fff;
    font-weight: bold;
    margin-top: 10px;
}
.Pending { background: #f0ad4e; }
.InProgress { background: #5bc0de; }
.Completed { background: #5cb85c; }
.info-list p { margin: 6px 0; }
.buttons {
    margin-top: 25px;
    display: flex;
    justify-content: center;
    gap: 15px;
}
.btn {
    background: #2e8b57;
    color: #fff;
    padding: 10px 20px;
    border-radius: 8px;
    text-decoration: none;
    transition: .3s;
}
.btn:hover { background: #236b45; }
.right img.preview {
    width: 100%;
    max-width: 300px;
    border-radius: 10px;
    margin-top: 20px;
}
</style>
</head>
<body>
<div class="container">
<?php if ($row): ?>

    <?php if (!empty($pickup_id) || !empty($mobile)): 
        $photo = (!empty($row['PHOTO'])) ? $row['PHOTO'] : 'assets/css/truck.jpg';
        $address = isset($row['ADDRESS']) && $row['ADDRESS'] instanceof OCILob ? $row['ADDRESS']->load() : ($row['ADDRESS'] ?? '');
        $status_raw = trim($row['STATUS'] ?? 'Pending');
        $status_clean = strtolower(str_replace(' ', '', $status_raw));
        if ($status_clean == 'inprogress') $status_class = 'InProgress';
        elseif ($status_clean == 'completed') $status_class = 'Completed';
        else $status_class = 'Pending';
    ?>
        <h1>📦 Pickup Status</h1>
        <p><strong>Pickup ID:</strong> <?= htmlspecialchars($row['PICKUP_ID']) ?></p>
        <div class="status <?= htmlspecialchars($status_class) ?>"><?= htmlspecialchars($status_raw) ?></div>

        <div class="info-list">
            <p><b>Name:</b> <?= htmlspecialchars($row['NAME']) ?></p>
            <p><b>Mobile:</b> <?= htmlspecialchars($row['MOBILE']) ?></p>
            <p><b>Date:</b> <?= htmlspecialchars($row['PICKUP_DATE']) ?> · <b>Time:</b> <?= htmlspecialchars($row['PICKUP_TIME']) ?></p>
            <p><b>Address:</b><br><?= nl2br(htmlspecialchars($address)) ?></p>
            <p><b>Description:</b><br><?= nl2br(htmlspecialchars($row['DESCRIPTION'])) ?></p>
        </div>
        <div class="right"><img class="preview" src="<?= htmlspecialchars($photo) ?>" alt="Uploaded Image"></div>

    <?php else: 
        $status_raw = trim($row['STATUS'] ?? 'Pending');
        $status_clean = strtolower(str_replace(' ', '', $status_raw));
        if ($status_clean == 'inprogress') $status_class = 'InProgress';
        elseif ($status_clean == 'completed') $status_class = 'Completed';
        else $status_class = 'Pending';
    ?>
        <h1>🛠 Complaint Status</h1>
        <p><strong>Complaint ID:</strong> <?= htmlspecialchars($row['COMPLAINT_ID']) ?></p>
        <div class="status <?= htmlspecialchars($status_class) ?>">
            <?= htmlspecialchars($status_raw) ?>
        </div>
        <div class="info-list">
            <p><b>Mobile:</b> <?= htmlspecialchars($row['MOBILE']) ?></p>
            <p><b>Forwarded To:</b> <?= htmlspecialchars($row['FORWARD_TO']) ?></p>
            <p><b>Message:</b><br><?= nl2br(htmlspecialchars($row['MESSAGE'])) ?></p>
            <p><b>Created At:</b> <?= htmlspecialchars($row['CREATED_AT']) ?></p>
        </div>
    <?php endif; ?>

    <div class="buttons">
        <a class="btn" href="index.html">🏠 Back to Home</a>
        <a class="btn" href="track.html">🔎 Try Another</a>
    </div>

<?php else: ?>
    <h2 style="text-align:center;color:#d9534f;">❌ No Record Found</h2>
    <p style="text-align:center;">Please check your Pickup ID, Mobile Number, or Complaint ID.</p>
    <div class="buttons">
        <a class="btn" href="track.html">🔙 Back to Track</a>
        <a class="btn" href="index.html">🏠 Home</a>
    </div>
<?php endif; ?>
</div>
</body>
</html>
