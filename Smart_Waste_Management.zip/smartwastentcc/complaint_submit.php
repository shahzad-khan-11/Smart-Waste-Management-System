<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';


$username = "smartwaste_ntcc";
$password = "waste123";
$connection_string = "localhost/orcl";
$conn = oci_connect($username, $password, $connection_string);

if (!$conn) {
    showPage("error", "❌ Database connection failed.");
    exit;
}

$pickup_id  = trim($_POST['pickup_id'] ?? '');
$mobile     = trim($_POST['mobile'] ?? '');
$email      = trim($_POST['email'] ?? '');
$forward_to = trim($_POST['forward_to'] ?? '');
$message    = trim($_POST['message'] ?? '');

if ($pickup_id === '' || $mobile === '' || $message === '' || $email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    showPage("error", "⚠️ All fields (including valid email) are required!");
    exit;
}

$sql = "SELECT pickup_id FROM pickup_requests WHERE pickup_id = :pid AND mobile = :mob";
$stid = oci_parse($conn, $sql);
oci_bind_by_name($stid, ":pid", $pickup_id);
oci_bind_by_name($stid, ":mob", $mobile);
oci_execute($stid);
$pickup = oci_fetch_array($stid, OCI_ASSOC);
oci_free_statement($stid);

if (!$pickup) {
    showPage("error", "❌ No matching pickup found.");
    exit;
}

$sql2 = "SELECT TO_CHAR(created_at, 'YYYY-MM-DD HH24:MI:SS') AS created_at FROM complaints WHERE pickup_id = :pid ORDER BY created_at DESC FETCH FIRST 1 ROWS ONLY";
$stid2 = oci_parse($conn, $sql2);
oci_bind_by_name($stid2, ":pid", $pickup_id);
oci_execute($stid2);
$row = oci_fetch_array($stid2, OCI_ASSOC);
oci_free_statement($stid2);

if ($row && isset($row['CREATED_AT'])) {
    $last = new DateTime($row['CREATED_AT']);
    $now = new DateTime();
    $diff = $now->diff($last)->days;
    if ($diff < 3) {
        showPage("error", "⚠️ Complaint already filed recently. Try again after " . (3 - $diff) . " day(s).");
        exit;
    }
}

$complaint_id = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
$sql3 = "INSERT INTO complaints (complaint_id, pickup_id, mobile, email, forward_to, message, status, created_at)
         VALUES (:cid, :pid, :mob, :email, :fwd, :msg, 'Pending', SYSTIMESTAMP)";
$stid3 = oci_parse($conn, $sql3);
oci_bind_by_name($stid3, ":cid", $complaint_id);
oci_bind_by_name($stid3, ":pid", $pickup_id);
oci_bind_by_name($stid3, ":mob", $mobile);
oci_bind_by_name($stid3, ":email", $email);
oci_bind_by_name($stid3, ":fwd", $forward_to);
oci_bind_by_name($stid3, ":msg", $message);
oci_execute($stid3);
oci_free_statement($stid3);

$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'khanshahzad90020@gmail.com';
    $mail->Password   = 'prgfgnfwsdybbede';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    $mail->setFrom('khanshahzad90020@gmail.com', 'Smart Waste System');
    $mail->addAddress('khanshahzad90020@gmail.com'); 
    $mail->addAddress($email); 

    $mail->isHTML(true);
    $mail->Subject = "🆕 Complaint Submitted - ID #$complaint_id";
    $mail->Body = "
        <h2>Complaint Received</h2>
        <p>Dear User,</p>
        <p>Your complaint has been received successfully.</p>
        <p><b>Complaint ID:</b> $complaint_id</p>
        <p><b>Pickup ID:</b> $pickup_id</p>
        <p><b>Forwarded To:</b> $forward_to</p>
        <p><b>Message:</b><br>" . nl2br(htmlspecialchars($message)) . "</p>
        <p>We’ll review your issue soon. Thank you for using Smart Waste System 💚</p>
    ";
    $mail->send();
} catch (Exception $e) {}

oci_close($conn);
showPage("success", $complaint_id);

function showPage($status, $info) {
    $color = $status === "error" ? "#dc3545" : "#28a745";
    $emoji = $status === "error" ? "⚠️" : "✅";
    $title = $status === "error" ? "Complaint Error" : "Complaint Submitted Successfully!";
    $text = $status === "error" ? $info : "Your Complaint ID is: <div class='complaint-id'>{$info}</div>";

    echo "
    <html><head><meta charset='UTF-8'>
    <title>$title</title>
    <style>
      body {font-family:Poppins;background:linear-gradient(-45deg,#56ab2f,#a8e063,#43cea2,#185a9d);background-size:400% 400%;animation:gradientMove 8s ease infinite;height:100vh;display:flex;justify-content:center;align-items:center;}
      @keyframes gradientMove{0%{background-position:0% 50%;}50%{background-position:100% 50%;}100%{background-position:0% 50%;}}
      .box{background:#ffffffee;border-radius:20px;padding:40px;text-align:center;box-shadow:0 6px 25px rgba(0,0,0,0.2);animation:fadeIn 1s ease-out;}
      @keyframes fadeIn{from{opacity:0;transform:scale(0.9);}to{opacity:1;transform:scale(1);}}
      .complaint-id{font-size:32px;color:#007bff;font-weight:bold;margin-top:10px;animation:glow 2s infinite alternate;}
      @keyframes glow{from{text-shadow:0 0 5px #007bff;}to{text-shadow:0 0 20px #00ffcc,0 0 30px #00ffcc;}}
      .btn{background:$color;color:white;padding:12px 25px;border-radius:8px;text-decoration:none;font-weight:bold;margin:10px;display:inline-block;}
    </style></head>
    <body><div class='box'>
    <h2>$emoji $title</h2><p>$text</p>
    <a href='index.html' class='btn'>🏠 Home</a>
    <a href='track.html' class='btn'>🔍 Track</a>
    </div></body></html>";
}
?>
