<?php
$username = "smartwaste_ntcc";
$password = "waste123";
$connection_string = "localhost/orcl"; 


$conn = oci_connect($username, $password, $connection_string);

if (!$conn) {
    $e = oci_error();
    echo "❌ Connection Failed: " . $e['message'];
} else {
    echo "✅ Oracle Database Connected Successfully!";
}
?>
