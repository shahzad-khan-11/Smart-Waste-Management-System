<?php
$username = "smartwaste_ntcc";
$password = "waste123";
$connection_string = "localhost/orcl";

$conn = oci_connect($username, $password, $connection_string);
if (!$conn) {
    $e = oci_error();
    die("<h2 style='color:red;text-align:center;'>❌ Database Connection Failed: " . $e['message'] . "</h2>");
}

$name = trim($_POST['name'] ?? '');
$mobile = trim($_POST['mobile'] ?? '');
$rating = trim($_POST['rating'] ?? '');
$message = trim($_POST['message'] ?? '');

if (empty($name) || empty($mobile) || empty($rating) || empty($message)) {
    die("<h2 style='color:red;text-align:center;'>⚠️ Please fill all required fields!</h2>");
}

$sql = "INSERT INTO feedback (name, mobile, rating, message, created_at) 
        VALUES (:name, :mobile, :rating, :message, CURRENT_TIMESTAMP)";
$stid = oci_parse($conn, $sql);

oci_bind_by_name($stid, ":name", $name);
oci_bind_by_name($stid, ":mobile", $mobile);
oci_bind_by_name($stid, ":rating", $rating);
oci_bind_by_name($stid, ":message", $message);

if (oci_execute($stid)) {
    oci_free_statement($stid);
    oci_close($conn);
} else {
    $e = oci_error($stid);
    die("<h2 style='color:red;text-align:center;'>❌ Error: " . $e['message'] . "</h2>");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Feedback Submitted</title>
<style>
body{font-family:'Segoe UI',sans-serif;background:linear-gradient(135deg,#2e8b57,#1c4b33);margin:0;padding:0;color:#fff;}
.container{max-width:600px;margin:100px auto;background:#fff;color:#333;padding:40px;border-radius:15px;box-shadow:0 8px 25px rgba(0,0,0,0.25);text-align:center;animation:fadeIn 1s ease-in-out;}
@keyframes fadeIn{from{opacity:0;transform:translateY(-20px);}to{opacity:1;transform:translateY(0);}}
h1{color:#136b3b;margin-bottom:15px;}
p{font-size:18px;margin:10px 0;}
.btn{display:inline-block;margin-top:20px;padding:12px 20px;background:#2e8b57;color:#fff;text-decoration:none;border-radius:8px;transition:.3s;}
.btn:hover{background:#236b45;}
.rating{font-size:22px;color:#f39c12;margin:10px 0;}
</style>
</head>
<body>
<div class="container">
  <h1>✅ Thank You for Your Feedback!</h1>
  <p><b>Name:</b> <?= htmlspecialchars($name) ?></p>
  <p><b>Mobile:</b> <?= htmlspecialchars($mobile) ?></p>
  <p><b>Your Rating:</b> <span class="rating"><?= str_repeat("⭐", (int)$rating) ?></span></p>
  <p><b>Message:</b><br><?= nl2br(htmlspecialchars($message)) ?></p>
  <a href="index.html" class="btn">🏠 Back to Home</a>
  <a href="feedback.html" class="btn">✍ Give More Feedback</a>
</div>
</body>
</html>
