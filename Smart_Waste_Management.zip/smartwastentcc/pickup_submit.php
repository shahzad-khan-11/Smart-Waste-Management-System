<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';

$username = "smartwaste_ntcc";
$password = "waste123";
$connection_string = "localhost/orcl";
$conn = oci_connect($username, $password, $connection_string);

if (!$conn) {
    $e = oci_error();
    die("<p style='color:red;text-align:center;'>❌ Connection Failed: " . $e['message'] . "</p>");
}

$name         = trim($_POST['name'] ?? '');
$mobile       = trim($_POST['mobile'] ?? '');
$email        = trim($_POST['email'] ?? '');
$address      = trim($_POST['address'] ?? '');
$description  = trim($_POST['description'] ?? '');
$pickup_date  = trim($_POST['pickup_date'] ?? '');
$pickup_time  = trim($_POST['pickup_time'] ?? '');

if (empty($name) || empty($mobile) || empty($address) || empty($description) || empty($pickup_date) || empty($pickup_time)) {
    die("<p style='color:red;text-align:center;'>❌ All required fields must be filled.</p>");
}

$pickup_id = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

$photo_name = null;
if (!empty($_FILES['photo']['name'])) {
    $upload_dir = __DIR__ . "/uploads/";
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

    $file_name = time() . "_" . basename($_FILES["photo"]["name"]);
    $target_path = $upload_dir . $file_name;

    if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_path)) {
        $photo_name = "uploads/" . $file_name;
    }
}

$sql = "INSERT INTO pickup_requests 
        (pickup_id, name, mobile, email, address, description, pickup_date, pickup_time, photo, status) 
        VALUES (:pickup_id, :name, :mobile, :email, :address, :description, TO_DATE(:pickup_date, 'YYYY-MM-DD'), :pickup_time, :photo, 'Pending')";

$stid = oci_parse($conn, $sql);
oci_bind_by_name($stid, ":pickup_id", $pickup_id);
oci_bind_by_name($stid, ":name", $name);
oci_bind_by_name($stid, ":mobile", $mobile);
oci_bind_by_name($stid, ":email", $email);
oci_bind_by_name($stid, ":address", $address);
oci_bind_by_name($stid, ":description", $description);
oci_bind_by_name($stid, ":pickup_date", $pickup_date);
oci_bind_by_name($stid, ":pickup_time", $pickup_time);
oci_bind_by_name($stid, ":photo", $photo_name);

$result = oci_execute($stid);
oci_commit($conn);
oci_free_statement($stid);
oci_close($conn);

if ($email != "") {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'khanshahzad90020@gmail.com'; 
        $mail->Password = 'prgfgnfwsdybbede'; 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('khanshahzad90020@gmail.com', 'Smart Waste System');
        $mail->addAddress($email, $name);

        $mail->isHTML(true);
        $mail->Subject = "✅ Pickup Request Received (ID #$pickup_id)";
        $mail->Body = "
            <h3>Dear $name,</h3>
            <p>Your pickup request <b>ID #$pickup_id</b> has been successfully received.</p>
            <p><b>Pickup Date:</b> $pickup_date<br>
            <b>Pickup Time:</b> $pickup_time</p>
            <p>We will notify you once it is <b>In Progress</b> and again when it's <b>Completed</b>.</p>
            <p>Thank you for helping us keep the city clean! 💚</p>
        ";

        $mail->send();
        $mail_status = "Email sent successfully to user.";
    } catch (Exception $e) {
        $mail_status = "Email failed to send.";
    }
}

if ($result) {
    echo "
    <!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <title>Pickup Success</title>
        <style>
            body {
                font-family: 'Poppins', sans-serif;
                background: linear-gradient(-45deg, #43cea2, #185a9d, #56ab2f, #a8e063);
                background-size: 400% 400%;
                animation: gradient 8s ease infinite;
                height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;
                color: #333;
            }
            @keyframes gradient {
                0% {background-position: 0% 50%;}
                50% {background-position: 100% 50%;}
                100% {background-position: 0% 50%;}
            }
            .card {
                background: #fff;
                border-radius: 20px;
                padding: 40px 50px;
                box-shadow: 0 8px 25px rgba(0,0,0,0.2);
                text-align: center;
                animation: fadeIn 1s ease-in-out;
            }
            @keyframes fadeIn {
                from {opacity: 0; transform: scale(0.9);}
                to {opacity: 1; transform: scale(1);}
            }
            h1 { color: #28a745; }
            .pickup-id {
                font-size: 32px;
                font-weight: bold;
                color: #007bff;
                margin-top: 10px;
                animation: glow 2s infinite alternate;
            }
            @keyframes glow {
                from { text-shadow: 0 0 5px #007bff; }
                to { text-shadow: 0 0 20px #00ffcc; }
            }
            .btn {
                background: #28a745;
                color: white;
                padding: 12px 25px;
                border-radius: 8px;
                text-decoration: none;
                margin: 10px;
                display: inline-block;
                transition: 0.3s;
            }
            .btn:hover {
                background: #218838;
                transform: scale(1.05);
            }
            img.preview {
                max-width: 200px;
                border-radius: 10px;
                margin-top: 15px;
                box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            }
        </style>
    </head>
    <body>
        <div class='card'>
            <h1>✅ Pickup Request Submitted!</h1>
            <p>Thank you, <b>$name</b>.</p>
            <p>Your Pickup ID is:</p>
            <div class='pickup-id'>$pickup_id</div>
            <p>Please save this ID to track your request.</p>";
            if ($photo_name) echo "<img src='$photo_name' alt='Uploaded Photo' class='preview'>";
    echo "
            <p style='color:green; font-weight:bold;'>$mail_status</p>
            <a href='index.html' class='btn'>🏠 Home</a>
        </div>
    </body>
    </html>";
} else {
    $e = oci_error($stid);
    echo "❌ Error submitting request: " . htmlspecialchars($e['message']);
}
?>
